package com.example.assignment7lv;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.assignment7lv.databinding.FragmentBooksBinding;

import java.util.ArrayList;
import java.util.List;


public class BooksFragment extends Fragment {

    final String TAG="demo";


    private static final String ARG_PARAM_GENRE= "ARG_PARAM_GENRE";


    private String mGenre;
    private ArrayList<Book> bookArrayList;


    public BooksFragment() {}


    public static BooksFragment newInstance(String Genre) {
        BooksFragment fragment = new BooksFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM_GENRE, Genre);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mGenre = getArguments().getString(ARG_PARAM_GENRE);
        }
    }
    FragmentBooksBinding binding;
    BooksAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       binding=FragmentBooksBinding.inflate(inflater,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        bookArrayList=Data.getBooksByGenre(mGenre);
        getActivity().setTitle(mGenre);
        binding.textViewGenre1.setText(bookArrayList.get(0).getGenre());

        adapter=new BooksAdapter(getActivity(),bookArrayList);
        binding.listView.setAdapter(adapter);
        binding.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Book book=bookArrayList.get(position);
                mListener.sendSelectedBook(book);
            }
        });

        binding.buttonback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.BackToGenres();
            }
        });

    }

    BooksListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener=(BooksListener) context;
    }

    interface BooksListener{
        void sendSelectedBook(Book book);
        void BackToGenres();
    }

    class BooksAdapter extends ArrayAdapter<Book>{


        public BooksAdapter(@NonNull Context context, @NonNull List<Book> objects) {
            super(context,R.layout.book_list_item, objects);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView== null) {
                convertView=getLayoutInflater().inflate(R.layout.book_list_item,parent,false);
            }
            TextView textViewBT=convertView.findViewById(R.id.textViewBT);
            TextView textViewAuthorN=convertView.findViewById(R.id.textViewAuthorN);
            TextView textViewGen=convertView.findViewById(R.id.textViewGen);
            TextView textViewYr=convertView.findViewById(R.id.textViewYr);

            Book book =getItem(position);
            textViewBT.setText(book.getTitle());
            textViewAuthorN.setText(book.getAuthor());
            textViewGen.setText(book.getGenre());
            textViewYr.setText(book.getYear()+"");


            return convertView;
        }
    }


}