package edu.charlotte.assignment10.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;
import java.util.function.Consumer;

import edu.charlotte.assignment10.R;
import edu.charlotte.assignment10.databinding.FragmentFilterBinding;
import edu.charlotte.assignment10.models.Data;
import edu.charlotte.assignment10.models.Mood;

public class FilterFragment extends Fragment {
    public FilterFragment() {
        // Required empty public constructor
    }

    FragmentFilterBinding binding;

    String selectedName = null;
    String selectedAgeGroup = null;
    String selectedMood = null;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentFilterBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.recyclerViewName.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.HORIZONTAL, false));
        binding.recyclerViewAge.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.HORIZONTAL, false));
        binding.recyclerViewFeeling.setLayoutManager(new GridLayoutManager(getContext(), 1, GridLayoutManager.HORIZONTAL, false));


        binding.recyclerViewName.setAdapter(new TextFilterAdapter(Data.(), name -> selectedName = name));
        binding.recyclerViewAge.setAdapter(new TextFilterAdapter(Data.getAgeGroups(), age -> selectedAgeGroup = age));
        binding.recyclerViewFeeling.setAdapter(new MoodAdapter(Data.getMoods(), mood -> selectedMood = mood.getName()));


        binding.buttonClearFilter.setOnClickListener(v -> {
            mListener.onFilterCleared();
            requireActivity().getSupportFragmentManager().popBackStack();
        });

    }



    FilterListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (FilterListener) context;
    }

    public interface FilterListener {
        void onFilterSelected(String name, String ageGroup, String mood);
        void onFilterCleared();
    }

    class TextFilterAdapter extends RecyclerView.Adapter<TextFilterAdapter.ViewHolder> {
        List<String> items;
        Consumer<String> onSelected;

        public TextFilterAdapter(List<String> items, Consumer<String> onSelected) {
            this.items = items;
            this.onSelected = onSelected;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_text_filter, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String item = items.get(position);
            holder.textView.setText(item);
            holder.itemView.setOnClickListener(v -> onSelected.accept(item));
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                textView = itemView.findViewById(R.id.textViewFilter);
            }
        }
    }

    class MoodAdapter extends RecyclerView.Adapter<MoodAdapter.ViewHolder> {
        List<Mood> moods;
        Consumer<Mood> onSelected;

        public MoodAdapter(List<Mood> moods, Consumer<Mood> onSelected) {
            this.moods = moods;
            this.onSelected = onSelected;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_mood, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Mood mood = moods.get(position);
            holder.textView.setText(mood.getName());
            holder.imageView.setImageResource(mood.getImageResourceId());
            holder.itemView.setOnClickListener(v -> onSelected.accept(mood));
        }

        @Override
        public int getItemCount() {
            return moods.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            ImageView imageView;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                textView = itemView.findViewById(R.id.textViewMoodName);
                imageView = itemView.findViewById(R.id.imageViewMoodIcon);
            }
        }
    }
}







}