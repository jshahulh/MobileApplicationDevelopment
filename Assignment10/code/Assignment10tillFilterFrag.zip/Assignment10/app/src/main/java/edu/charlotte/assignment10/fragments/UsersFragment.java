package edu.charlotte.assignment10.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import edu.charlotte.assignment10.databinding.FragmentUsersBinding;
import edu.charlotte.assignment10.databinding.ListItemUserBinding;
import edu.charlotte.assignment10.models.User;

public class UsersFragment extends Fragment {

    public UsersFragment() {}
    FragmentUsersBinding binding;
    ArrayList<User> mUsers = new ArrayList<>();
    UsersAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentUsersBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Users");
        mUsers = mListener.getAllUsers();
        adapter = new UsersAdapter(mUsers);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerView.setAdapter(adapter);

        binding.buttonClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mListener.clearAll();
                adapter.updateUsers(new ArrayList<>());
            }
        });

        binding.buttonAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoAddNew();
            }
        });

        binding.imageViewSort.setOnClickListener(v -> {
            mListener.gotoSortSelection(); //
        });


        binding.textViewSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoSortSelection();
            }
        });
        binding.textViewFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoFilterSelection();
            }
        });
    }

    class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.UserViewHolder>{
        ArrayList<User> users;
        public UsersAdapter(ArrayList<User> users){  this.users = users;}
        public void updateUsers(ArrayList<User> newUsers)
        {
            this.users = newUsers;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ListItemUserBinding binding = ListItemUserBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new UserViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
            User user = users.get(position);
            Log.d("demo", "onBindViewHolder: "+user.toString());
            holder.binding.textViewUserName.setText(user.getName());
            holder.binding.textViewUserAgeGroup.setText(user.getAgeGroup());
            holder.binding.imageViewUserMood.setImageResource(user.getMood().getImageResourceId());

            holder.binding.getRoot().setOnClickListener(v -> mListener.gotoUserProfile(user));
            holder.binding.imageViewDelete.setOnClickListener(v -> {
                mListener.deletUser(user);
                notifyDataSetChanged();
            });
        }

        @Override
        public int getItemCount() {
            return users.size();
        }

        class UserViewHolder extends RecyclerView.ViewHolder{
            ListItemUserBinding binding;


            public UserViewHolder(@NonNull ListItemUserBinding binding) {
                super(binding.getRoot());
                this.binding = binding;

            }
        }
    }

    public void refreshUsers() {
        mUsers = mListener.getAllUsers();
        adapter.updateUsers(mUsers);
    }



    UsersListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            mListener = (UsersListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement UsersListener");
        }
    }

    public interface UsersListener{
        void clearAll();
        void gotoAddNew();
        ArrayList<User> getAllUsers();
        void gotoUserProfile(User user);
        void gotoSortSelection();
        void gotoFilterSelection();
        void deletUser (User user);
    }

}