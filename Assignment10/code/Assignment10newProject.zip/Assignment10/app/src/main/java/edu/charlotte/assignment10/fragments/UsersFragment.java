package edu.charlotte.assignment10.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import edu.charlotte.assignment10.databinding.FragmentUsersBinding;
import edu.charlotte.assignment10.databinding.ListItemUserBinding;
import edu.charlotte.assignment10.models.User;

public class UsersFragment extends Fragment {
    public UsersFragment() {
        // Required empty public constructor
    }

    FragmentUsersBinding binding;
    ArrayList<User> mUsers = new ArrayList<>();

    UserAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentUsersBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Users");
        mUsers=mListener.getAllUsers();
        adapter= new UserAdapter(mUsers);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerView.setAdapter(adapter);






        binding.buttonClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mListener.clearAll();
                adapter.updateUsers(new ArrayList<>() );


            }
        });

        binding.buttonAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoAddNew();
            }
        });
    }

    UsersListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            mListener = (UsersListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement UsersListener");
        }
    }

    public interface UsersListener{
        void clearAll();
        void gotoAddNew();
        ArrayList<User> getAllUsers();
        void gotoUserProfile(User user);
        void gotoSortSelection();
        void gotoFilterSelection();
        void deleteUser(User user);
    }


    class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder>{

        ArrayList<User> users;

        public UserAdapter(ArrayList<User> users){
            this.users=users;
        }

        public void updateUsers(ArrayList<User> newUsers){
            this.users = newUsers;
            notifyDataSetChanged();

        }
        @NonNull
        @Override
        public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ListItemUserBinding binding = ListItemUserBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new UserViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
            User user =users.get(position);
            holder.binding.textViewUserName.setText(user.getName());
            holder.binding.textViewUserAgeGroup.setText(user.getAgeGroup());
            holder.binding.imageViewUserMood.setImageResource(user.getMood().getImageResourceId());
            holder.binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.gotoUserProfile(user);
                }
            });

            holder.binding.imageViewDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.deleteUser(user);
                    notifyDataSetChanged();
                }
            });


        }

        @Override
        public int getItemCount() {
            return users.size();
        }

        class UserViewHolder extends RecyclerView.ViewHolder{

            ListItemUserBinding binding;
            public UserViewHolder(@NonNull ListItemUserBinding binding) {
                super(binding.getRoot());
                this.binding = binding;


            }
        }

    }


}