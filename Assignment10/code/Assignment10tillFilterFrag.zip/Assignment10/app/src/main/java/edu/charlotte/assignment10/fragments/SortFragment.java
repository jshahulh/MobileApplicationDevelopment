package edu.charlotte.assignment10.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import edu.charlotte.assignment10.databinding.FragmentSortBinding;

public class SortFragment extends Fragment {
    FragmentSortBinding binding;

    public SortFragment() {}


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSortBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.imageViewNameAsc.setOnClickListener(v -> {
            mListener.onSortSelected("name_asc");
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        binding.imageViewNameDesc.setOnClickListener(v -> {
            mListener.onSortSelected("name_desc");
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        binding.imageViewAgeAsc.setOnClickListener(v -> {
            mListener.onSortSelected("age_asc");
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        binding.imageViewAgeDesc.setOnClickListener(v -> {
            mListener.onSortSelected("age_desc");
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        binding.imageViewFeelingAsc.setOnClickListener(v -> {
            mListener.onSortSelected("mood_asc");
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        binding.imageViewFeelingDesc.setOnClickListener(v -> {
            mListener.onSortSelected("mood_desc");
            requireActivity().getSupportFragmentManager().popBackStack();
        });

        binding.buttonCancel.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager().popBackStack();
        });

    }

    SortListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (SortFragment.SortListener) context;
    }

    public interface SortListener{
        void onSortSelected(String criteria);
    }
}